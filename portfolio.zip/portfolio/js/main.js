/* ============================================================
   PORTFOLIO — main.js
   ============================================================ */

// ── Language toggle ──────────────────────────────────────────
const TRANSLATIONS = {
  es: {
    'nav.home':     'Inicio',
    'nav.projects': 'Proyectos',
    'nav.skills':   'Habilidades',
    'nav.about':    'Sobre mí',
    'nav.contact':  'Contacto',

    'hero.tag':      'Generalista 3D · Artista Digital · Desarrollador',
    'hero.title':    'Álvaro<br><em>García</em>',
    'hero.subtitle': 'Creación de mundos 3D, visualización arquitectónica, arte digital e indie games. Del concepto al píxel final.',
    'hero.cta1':     'Ver proyectos',
    'hero.cta2':     'CV',
    'hero.stat1':    'Proyectos',
    'hero.stat2':    'Años exp.',
    'hero.stat3':    'Herramientas',
    'hero.recent':   'Trabajos recientes',

    'projects.eyebrow': 'Galería',
    'projects.title':   'Proyectos',
    'projects.sub':     'Visualización 3D, arte digital y videojuegos.',
    'filter.all':   'Todo',
    'filter.3d':    '3D / Arq.',
    'filter.art':   'Arte digital',
    'filter.game':  'Games',

    'skills.eyebrow': 'Stack',
    'skills.title':   'Habilidades',
    'skills.sub':     'Software, técnicas y flujos de trabajo que domino.',

    'about.eyebrow': 'Quién soy',
    'about.title':   'Sobre mí',
    'about.p1':      'Soy Álvaro García, artista 3D generalista y desarrollador de videojuegos indie con base en España.',
    'about.p2':      'Mi trabajo abarca desde visualización arquitectónica y renders fotorrealistas hasta ilustración digital y pequeños juegos con Godot. Me apasiona la unión entre técnica y narrativa visual.',
    'about.p3':      'Trabajo con un pipeline PBR completo: modelado en 3ds Max, unwrap con RizomUV, texturizado en Substance Painter y render con Corona. Para juegos uso Godot con GDScript y shaders GLSL.',
    'about.exp':     'Experiencia',
    'about.cv':      'Descargar CV',

    'contact.eyebrow': 'Hablemos',
    'contact.title':   'Contacto',
    'contact.sub':     'Disponible para proyectos freelance, colaboraciones y nuevas oportunidades.',
    'contact.name':    'Nombre',
    'contact.email':   'Email',
    'contact.msg':     'Mensaje',
    'contact.send':    'Enviar mensaje',
    'contact.success': 'Mensaje enviado. ¡Te contesto pronto!',

    'footer.copy': '© 2025 Álvaro García. Todos los derechos reservados.',
  },
  en: {
    'nav.home':     'Home',
    'nav.projects': 'Projects',
    'nav.skills':   'Skills',
    'nav.about':    'About',
    'nav.contact':  'Contact',

    'hero.tag':      '3D Generalist · Digital Artist · Developer',
    'hero.title':    'Álvaro<br><em>García</em>',
    'hero.subtitle': 'Building 3D worlds, architectural visualisations, digital art and indie games. From concept to final pixel.',
    'hero.cta1':     'View projects',
    'hero.cta2':     'CV',
    'hero.stat1':    'Projects',
    'hero.stat2':    'Yrs exp.',
    'hero.stat3':    'Tools',
    'hero.recent':   'Recent work',

    'projects.eyebrow': 'Gallery',
    'projects.title':   'Projects',
    'projects.sub':     '3D visualisation, digital art and video games.',
    'filter.all':   'All',
    'filter.3d':    '3D / Arch.',
    'filter.art':   'Digital art',
    'filter.game':  'Games',

    'skills.eyebrow': 'Stack',
    'skills.title':   'Skills',
    'skills.sub':     'Software, techniques and workflows I master.',

    'about.eyebrow': 'Who I am',
    'about.title':   'About me',
    'about.p1':      'I\'m Álvaro García, a 3D generalist artist and indie game developer based in Spain.',
    'about.p2':      'My work spans architectural visualisation and photorealistic renders to digital illustration and small games with Godot. I\'m passionate about the intersection of technique and visual storytelling.',
    'about.p3':      'I work with a full PBR pipeline: modelling in 3ds Max, unwrapping with RizomUV, texturing in Substance Painter and rendering with Corona. For games I use Godot with GDScript and GLSL shaders.',
    'about.exp':     'Experience',
    'about.cv':      'Download CV',

    'contact.eyebrow': 'Get in touch',
    'contact.title':   'Contact',
    'contact.sub':     'Available for freelance projects, collaborations and new opportunities.',
    'contact.name':    'Name',
    'contact.email':   'Email',
    'contact.msg':     'Message',
    'contact.send':    'Send message',
    'contact.success': 'Message sent. I\'ll get back to you soon!',

    'footer.copy': '© 2025 Álvaro García. All rights reserved.',
  }
};

let currentLang = localStorage.getItem('lang') || 'es';

function t(key) {
  return TRANSLATIONS[currentLang][key] || key;
}

function applyLang() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    const val = t(key);
    if (val) el.innerHTML = val;
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.dataset.i18nPlaceholder;
    const val = t(key);
    if (val) el.placeholder = val;
  });
  const btn = document.getElementById('langToggle');
  if (btn) btn.textContent = currentLang === 'es' ? 'EN' : 'ES';
  document.documentElement.lang = currentLang;
}

function toggleLang() {
  currentLang = currentLang === 'es' ? 'en' : 'es';
  localStorage.setItem('lang', currentLang);
  applyLang();
}

// ── Mobile nav ───────────────────────────────────────────────
function initMobileNav() {
  const burger = document.getElementById('navBurger');
  const mobileMenu = document.getElementById('mobileMenu');
  if (!burger || !mobileMenu) return;
  burger.addEventListener('click', () => {
    const open = burger.classList.toggle('open');
    mobileMenu.classList.toggle('open', open);
  });
  mobileMenu.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      burger.classList.remove('open');
      mobileMenu.classList.remove('open');
    });
  });
}

// ── Active nav link ──────────────────────────────────────────
function setActiveNav() {
  const page = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav__links a, .nav__mobile a').forEach(a => {
    const href = a.getAttribute('href');
    a.classList.toggle('active', href === page || (page === 'index.html' && href === 'index.html'));
  });
}

// ── Skill bars animate on view ───────────────────────────────
function initSkillBars() {
  const bars = document.querySelectorAll('.skill-bar__fill');
  if (!bars.length) return;
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('animated');
        obs.unobserve(e.target);
      }
    });
  }, { threshold: 0.3 });
  bars.forEach(b => obs.observe(b));
}

// ── Project filter ───────────────────────────────────────────
function initFilter() {
  const btns = document.querySelectorAll('.filter-btn');
  const items = document.querySelectorAll('.project-item');
  if (!btns.length) return;
  btns.forEach(btn => {
    btn.addEventListener('click', () => {
      btns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.dataset.filter;
      items.forEach(item => {
        const show = cat === 'all' || item.dataset.cat === cat;
        item.style.display = show ? '' : 'none';
      });
    });
  });
}

// ── Modal lightbox ───────────────────────────────────────────
function initModal() {
  const overlay = document.getElementById('modalOverlay');
  if (!overlay) return;
  const closeBtn = document.getElementById('modalClose');
  const items = document.querySelectorAll('.project-item');

  function openModal(item) {
    const data = item.dataset;
    overlay.querySelector('.modal__cat').textContent = data.cat || '';
    overlay.querySelector('.modal__title').textContent = data.title || '';
    overlay.querySelector('.modal__desc').textContent = data.desc || '';
    const mediaWrap = overlay.querySelector('.modal__media');
    if (data.video) {
      mediaWrap.innerHTML = `<video src="${data.video}" autoplay muted loop playsinline></video>`;
    } else {
      mediaWrap.innerHTML = `<img src="${data.img || ''}" alt="${data.title || ''}">`;
    }
    const tagsWrap = overlay.querySelector('.modal__tags');
    tagsWrap.innerHTML = (data.tags || '').split(',').map(t => `<span class="modal__tag">${t.trim()}</span>`).join('');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    overlay.classList.remove('open');
    document.body.style.overflow = '';
    const v = overlay.querySelector('video');
    if (v) v.pause();
  }

  items.forEach(item => {
    item.addEventListener('click', () => openModal(item));
    item.addEventListener('keydown', e => { if (e.key === 'Enter') openModal(item); });
    item.setAttribute('tabindex', '0');
    item.setAttribute('role', 'button');
  });

  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
}

// ── Contact form (demo) ──────────────────────────────────────
function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;
  form.addEventListener('submit', e => {
    e.preventDefault();
    const success = document.getElementById('formSuccess');
    if (success) {
      success.style.display = 'block';
      form.reset();
      setTimeout(() => { success.style.display = 'none'; }, 5000);
    }
  });
}

// ── Scroll: shrink nav shadow ────────────────────────────────
function initNavScroll() {
  const nav = document.querySelector('.nav');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    nav.style.borderBottomColor = window.scrollY > 20 ? 'var(--bg-line)' : 'transparent';
  }, { passive: true });
}

// ── Init ─────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const langBtn = document.getElementById('langToggle');
  if (langBtn) langBtn.addEventListener('click', toggleLang);
  applyLang();
  setActiveNav();
  initMobileNav();
  initSkillBars();
  initFilter();
  initModal();
  initContactForm();
  initNavScroll();
});
