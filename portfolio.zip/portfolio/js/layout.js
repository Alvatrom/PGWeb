/* ============================================================
   layout.js — injects shared nav + footer into every page
   ============================================================ */

const NAV_HTML = `
<nav class="nav" role="navigation" aria-label="Principal">
  <div class="nav__inner">
    <a href="index.html" class="nav__logo">Álvaro <span>García</span></a>
    <ul class="nav__links" role="list">
      <li><a href="index.html"    data-i18n="nav.home">Inicio</a></li>
      <li><a href="projects.html" data-i18n="nav.projects">Proyectos</a></li>
      <li><a href="skills.html"   data-i18n="nav.skills">Habilidades</a></li>
      <li><a href="about.html"    data-i18n="nav.about">Sobre mí</a></li>
      <li><a href="contact.html"  data-i18n="nav.contact">Contacto</a></li>
    </ul>
    <div class="nav__controls">
      <button class="nav__lang" id="langToggle" aria-label="Cambiar idioma">EN</button>
      <button class="nav__burger" id="navBurger" aria-label="Menú" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
    </div>
  </div>
</nav>
<div class="nav__mobile" id="mobileMenu" role="menu">
  <a href="index.html"    data-i18n="nav.home">Inicio</a>
  <a href="projects.html" data-i18n="nav.projects">Proyectos</a>
  <a href="skills.html"   data-i18n="nav.skills">Habilidades</a>
  <a href="about.html"    data-i18n="nav.about">Sobre mí</a>
  <a href="contact.html"  data-i18n="nav.contact">Contacto</a>
</div>
`;

const FOOTER_HTML = `
<footer class="footer">
  <div class="container">
    <div class="footer__inner">
      <span class="footer__copy" data-i18n="footer.copy">© 2025 Álvaro García. Todos los derechos reservados.</span>
      <nav class="footer__links" aria-label="Footer">
        <a href="projects.html" data-i18n="nav.projects">Proyectos</a>
        <a href="contact.html"  data-i18n="nav.contact">Contacto</a>
      </nav>
    </div>
  </div>
</footer>
`;

document.addEventListener('DOMContentLoaded', () => {
  // Inject nav at top of body
  const navPlaceholder = document.getElementById('nav-placeholder');
  if (navPlaceholder) navPlaceholder.outerHTML = NAV_HTML;

  // Inject footer
  const footerPlaceholder = document.getElementById('footer-placeholder');
  if (footerPlaceholder) footerPlaceholder.outerHTML = FOOTER_HTML;
});
